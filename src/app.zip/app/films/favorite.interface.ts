export interface Favorite {
    favId: number;
    favTitle: string;
}