export interface FavoriteResponse {
    name: string;
}