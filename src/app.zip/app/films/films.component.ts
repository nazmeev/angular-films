import { Component, OnInit, Input } from '@angular/core';
import { FilmsService } from './films.service';
import { Film } from './film.interface';
import { Subscription } from 'rxjs';
import { FavoriteService } from './favorite.service';
import { Favorite } from './favorite.interface';

@Component({
  selector: 'app-films',
  templateUrl: './films.component.html',
  styleUrls: ['./films.component.css']
})

export class FilmsComponent implements OnInit {
  public films: Film[] = [];
  public favorites: Favorite[] = [];
  // public page:number = 1;
  public filmItem:Film;
  public imgPath = this.filmsService.smallImgPath;
  public moreActivePopular: boolean = true;
  public totalPopular: number;
  public visibility: string;

  subscription: Subscription;
  

  // @Input() search: string;

  constructor(
    private filmsService: FilmsService,
    private FavoriteService: FavoriteService
  ) {
    //this.route.queryParams.subscribe(params => console.log('this.route.queryParams', params));
  }

  ngOnInit(): void {
    // console.log('films.component')
    // console.log(this.filmsService.page)
    // console.log('getFilmsPopular', this.getFilmsPopular());
    this.getPopularFilms()
    this.getVisibility()
    this.getFavoritedFilms()
    console.log('this.favorites1', this.favorites);
    this.subscription = this.filmsService.filmsFiltered$.subscribe(
      films => this.films = films
    )
    this.subscription = this.filmsService.moreVisibled$.subscribe(
      visibility => this.visibility = visibility
    )
  }

  // getFilmsPopular(page){
  //   this.filmsService.loadPopularFilms(page).subscribe(
  //     (filmList: any) => {
  //       this.totalPopular = filmList.total_pages;
  //       filmList.results.forEach(element => {
  //         this.filmsPopular.push(element);
  //       });
  //       this.filmsService.filmsPopular = this.filmsPopular;
  //     }
  //   )
  // }
  getPopularFilms(){
    this.films = this.filmsService.getPopularFilms()
  }
  getFavoritedFilms(){
    this.FavoriteService.load().subscribe(favorites => {
      this.favorites = favorites
      console.log('this.favorites2', this.favorites);
    })
  }
  // searchFilm(text){
  //   console.log('text', text);
  //   // this.filmsPopular = (text.length < 4) ?  this.filmsPopular : this.filmsService.getSearch(text)
  // }

  getVisibility(){  
    this.visibility = this.filmsService.visibility
  }

  loadMore(){
    // this.page = this.page + 1;
    this.filmsService.page = this.filmsService.page + 1;
    
    // alert(this.page) //чому обнуляється ? при перході на людей і назад 
    // а сервис не обнуляется ????
    if(this.filmsService.page >= this.totalPopular){
      this.moreActivePopular = false;
    }else{
      console.log(this.films.length)
      let moreFilms = this.filmsService.getMoreFilmsPopular();
      moreFilms.map(film => this.films.push(film))
      console.log(this.films.length)
    }
  }



  addFavorite(id: number){
    let film = this.films.filter(item => item.id == id)
    
    let favId: number = film[0].id;
    let favTitle: string = film[0].title;

    const favorite: Favorite = {
      favId,
      favTitle
    }
    this.FavoriteService.create(favorite).subscribe(fav => {
      // console.log('this.favorites.length1', this.favorites.length)
      this.favorites.push(fav)
      this.changeFilms()
      // console.log('this.favorites.length2', this.favorites.length)
    }, err => console.error( err ))
    // this.favorites = this.filmService.getFavorites();
    // this.totalFavorited();
  }
  removeFavorite(id:number){
    this.FavoriteService.remove(id).subscribe(() => {
      // console.log('this.favorites.length1', this.favorites.length)
      this.favorites = this.favorites.filter(item => item.favId != id)
      this.changeFilms()
      // console.log('this.favorites.length2', this.favorites.length)
    })
  }

  changeFilms(){
    this.films.map(item => {
      console.log('item', item.favorited)
      let f = this.favorites.filter(fav => fav.favId == item.id)
      f.length ? item.favorited = true : item.favorited = false
    })
  }
}
