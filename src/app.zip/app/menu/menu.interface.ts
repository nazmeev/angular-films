export class Menu {
    path:string;
    label:string;
    active:string;
    icon:string;
}