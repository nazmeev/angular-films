import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter, Input, AfterViewInit } from '@angular/core';
import { FilmsService } from '../films/films.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit, AfterViewInit {
  searchControl: FormControl;
  
  // @Input() search:string;
  // public searchText: string;
  // @Output() searchText = new EventEmitter<string>();
  
  constructor(private filmsService: FilmsService){

  }

  @ViewChild("searchInput", {static: false})
    nameParagraph: ElementRef;
    name: string;
     
    change() { 
        console.log(this.nameParagraph.nativeElement.textContent); 
        this.nameParagraph.nativeElement.focus();
    }
  // @ViewChild("searchInput", { read: ElementRef }) 
  // public searchValue: ElementRef;

  ngOnInit(): void {
    this.searchControl = new FormControl()
    // this.searchValue.nativeElement.focus();
  }
  ngAfterViewInit(): void {
    this.nameParagraph.nativeElement.focus();
  }
  // ngaftervoewinit

  // searchFilm(text: string) {
  //   this.searchText.emit(text);
  // }

  searchFilm(search){
    let films = this.filmsService.getSearch(search);
  }

}
