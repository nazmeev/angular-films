import { Component, ViewChild, SimpleChanges} from '@angular/core';
import { CounterComponent } from './counter/counter.component';
import { SearchComponent } from './search/search.component';
import { FilmsComponent } from './films/films.component';
import { Router, Event, NavigationStart, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'films catalog server';
  
  // @ViewChild(SearchComponent, {static: false})
  // public search: SearchComponent;

  // @ViewChild(FilmsComponent, {static: false})
  // public films: FilmsComponent;

  @ViewChild(CounterComponent, {static: false})
  private counter: CounterComponent;
  
  increment() { this.counter.increment(); }
  decrement() { this.counter.decrement(); }

  // searchFilm(text:string){
  //   // console.log(this.counter.counter);
  //   // console.log(this.search.searchText);
  //   console.log('text', text);
  //   // this.films.searchFilm;
  // }
  // @ViewChild(SearchComponent)
  // search: SearchComponent;

  // @ViewChild("searchInput", { read: ElementRef }) 
  // public searchValue: ElementRef;
  
  ngOnChanges(changes: SimpleChanges){
    console.log('проперти в App поменялись');
    for(let key in changes){
      console.log(`key=  ${key}`)
      console.log('key=',  changes[key])
    }
  }

  //почему не видно на малой скорости?
  // public showLoaderIndicator:string = 'hidden';
  // constructor(private router: Router){
  //   this.router.events.subscribe((routerEvent: Event) => {
  //     if(routerEvent instanceof NavigationStart){
  //       // alert('loading')
  //       this.showLoaderIndicator = 'visible';
  //     }
  //     if(routerEvent instanceof NavigationEnd){
  //       this.showLoaderIndicator = 'hidden';
  //     }
  //   })
  // }



}
