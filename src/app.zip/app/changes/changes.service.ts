import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChangesService {
  public page:number = 1;
  public urlChanges = 'https://api.themoviedb.org/3/movie/changes'

  constructor(private http: HttpClient) { }

  getChanges(){
      this.http.get(`${this.urlChanges}?page=${this.page}`).subscribe((response) => {
        response['results'].forEach(element => {
          console.log('getChangesforEach', element)
        });
        
        return response['results']
      }, (error) => {
        alert('Error getChanges!')
      })
  }
}
