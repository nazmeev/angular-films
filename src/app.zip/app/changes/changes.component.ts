import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ChangesService } from './changes.service';

@Component({
  selector: 'app-changes',
  templateUrl: './changes.component.html',
  styleUrls: ['./changes.component.css']
})
export class ChangesComponent implements OnInit {

  changes;

  constructor(private ChangesService: ChangesService) {}

  ngOnInit(): void {
    
    this.changes = this.ChangesService.getChanges();
    console.log('ngOnInit', this.changes);
    
  }

}
