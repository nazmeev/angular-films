import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FilmsComponent } from './films/films.component';
import { PeopleComponent } from './people/people.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { FilmComponent } from './film/film.component';
import { ChangesComponent } from './changes/changes.component';
import { MissioncontrolComponent } from './missioncontrol/missioncontrol.component';

const appRoutes: Routes = [
  {path: 'missions', component: MissioncontrolComponent},
  {path: 'films', component: FilmsComponent},
  {path: 'people', component: PeopleComponent},
  {path: 'changes', component: ChangesComponent},
  {path: 'films/:filmId', component: FilmComponent},
  {path: '**', component:  NotFoundComponent},
]
@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }