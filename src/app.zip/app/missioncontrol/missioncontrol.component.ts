import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { MissionService } from './mission.service';

@Component({
  selector: 'app-missioncontrol',
  templateUrl: './missioncontrol.component.html',
  styleUrls: ['./missioncontrol.component.css']
})
export class MissioncontrolComponent implements OnInit {

  astronauts = ['Василий', 'Юрий', 'Андрей'];
  history: string[] = [];
  missions = ['Полететь на Луну!', 'Полететь на Марс!', 'Полететь на Венеру!'];
  subscription: Subscription;
  nextMission = 0;

  constructor(private missionService: MissionService) {}

  ngOnInit() {
    this.subscription = this.missionService.missionConfirmed$.subscribe(
      astronaut => {
        this.history.push(`${astronaut} готов принять участие в миссии!`);
      }
    )
  }

  announce() {
    const mission = this.missions[this.nextMission++];
    this.missionService.announceMission(mission);
    this.history.push(`Миссия "${mission}" ждет своего героя!`);
    if (this.nextMission >= this.missions.length) {
      this.nextMission = 0;
    }
  }

 

}
